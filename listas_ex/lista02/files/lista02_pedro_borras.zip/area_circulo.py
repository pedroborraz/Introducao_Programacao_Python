raio = float(input("Digite um valor de raio: "))

area = 3.14 * raio ** 2

print(f"O valor da area do circulo com raio correspondente e: {area:.2f}")